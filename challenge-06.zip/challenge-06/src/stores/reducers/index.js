import { combineReducers } from "redux";
import carReducer from "./car";

const rootReducers = combineReducers ({
    carReducer
})

export default rootReducers;